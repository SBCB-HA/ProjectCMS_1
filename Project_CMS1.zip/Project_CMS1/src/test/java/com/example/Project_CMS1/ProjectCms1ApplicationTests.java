package com.example.Project_CMS1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectCms1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
