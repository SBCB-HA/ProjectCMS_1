package com.example.Project_CMS1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectCms1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectCms1Application.class, args);
	}

}
